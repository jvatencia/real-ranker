export interface RadarItem {
    name: string;
    dataKey: string;
}