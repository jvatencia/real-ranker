export const MOCK_WHATS_NEW_VIDEOS = [
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
    { url: '#', thumbnail: '' },
];