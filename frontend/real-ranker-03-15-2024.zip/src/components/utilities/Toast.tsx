import { Snackbar, Alert } from "@mui/material";

export default function Toast() {
    return (
        <></>
    );
}