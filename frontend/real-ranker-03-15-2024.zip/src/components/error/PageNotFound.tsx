import React from "react";

const PageNotFound = () => {
  window.location.replace("https://thetestguytutors.com/login/");

  return (
    <div>
      <h1>REDIRECT TO SIGN UP!!</h1>
    </div>
  );
};

export default PageNotFound;
