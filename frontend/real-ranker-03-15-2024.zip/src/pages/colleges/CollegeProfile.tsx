export default function CollegeProfile() {
    return (
        <>
        </>
    );
}